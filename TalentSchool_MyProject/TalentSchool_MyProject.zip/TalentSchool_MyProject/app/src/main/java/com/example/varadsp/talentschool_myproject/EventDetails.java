package com.example.varadsp.talentschool_myproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class EventDetails extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);



        TextView eventName = (TextView)findViewById(R.id.eventName);
        TextView eventDescr = (TextView)findViewById(R.id.eventDescr);
        TextView eventDate = (TextView)findViewById(R.id.eventDate);








        Intent i = getIntent();


        String EventName = i.getStringExtra("EventName");
        String EventDescr = i.getStringExtra("EventDescr");
        String EventDate = i.getStringExtra("EventDate");





//        URL url = null;
//        try {
//            url = new URL(ImageUrl);
//        } catch (MalformedURLException e) {
//            e.printStackTrace();
//        }
//        Bitmap bmp = null;
//        try {
//            bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        imageView.setImageBitmap(bmp);



        eventName.setText(EventName);
        eventDescr.setText(EventDescr);
        eventDate.setText(EventDate);







    }

    @Override
    protected void onStart() {
        super.onStart();

        Intent i = getIntent();

        String ImageUrl = i.getStringExtra("ImageUrl");

        ImageView imageView= (ImageView)findViewById(R.id.eventImage);

        Picasso.get().load(ImageUrl).into(imageView);



    }
}
