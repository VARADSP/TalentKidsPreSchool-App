package com.example.varadsp.talentschool_myproject;

/**
 * Created by VARAD on 22-03-2018.
 */

public class VideoClass {
    String videoName;
    String videoUrl;

    public VideoClass(){

    }

    public VideoClass(String videoName, String videoUrl) {
        this.videoName = videoName;
        this.videoUrl = videoUrl;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
